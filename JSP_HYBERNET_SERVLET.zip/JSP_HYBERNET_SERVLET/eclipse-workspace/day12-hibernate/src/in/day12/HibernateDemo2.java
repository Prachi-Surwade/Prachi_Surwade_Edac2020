package in.day12;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.build.AllowSysOut;

public class HibernateDemo2 {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {
		//create();
		//update();
		//delete();
		//updateSpecialColumn();
		readAll();
	}
	
	public static void readAll() {
		Session session = sessionFactory.openSession();
		List<Person> list = session.createQuery("FROM Person", Person.class).list();
		list.stream().forEach(System.out::println);
		session.close();
	}
	public static void updateSpecialColumn() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Person p = session.find(Person.class, 1); //pass the (class and key)
		System.out.println(p.getId()); //for checking purpose what it returns
		p.setFirstName("pranit");
		p.setMiddleName("xyz");
		p.setLastName("gundare");
		tx.commit();
		session.close();
	}
	public static void delete() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Person p = new Person();
		p.setId(4);
		session.delete(p);
		tx.commit();
		session.close();
	}
	public static void update() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Person p = new Person();
		p.setId(4);
		p.setFirstName("payal");
		p.setMiddleName("pandurang");
		p.setLastName("jadhav");
		session.update(p);
		tx.commit();
		session.close();
	}
	public static void create() {
		 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction(); //it must write without this our changes will not reflected in database
			
			Person p = new Person();
			p.setFirstName("prafulla");
			p.setMiddleName("prakash");
			p.setLastName("gaikwad");
			session.save(p);
			
			tx.commit();
			 session.close();
	}
}

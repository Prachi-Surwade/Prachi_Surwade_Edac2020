package day.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Hellojdbc6 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/day5";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";

	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enetr username");
			String username = sc.nextLine();

			System.out.println("Enetr email");
			String email = sc.nextLine();

			System.out.println("Enetr password");
			String password = sc.nextLine();

			System.out.println("Enetr mobile");
			String mobile = sc.nextLine();
			
			System.out.println(username + password + email + mobile);

			Class.forName(DB_DRIVER);
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

			String query = "INSERT INTO USER (USERNAME,EMAIL,PASSWORD,MOBILE) VALUES (' "+username+"','"+email+"','"+password+"','"+mobile+"')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
			System.out.println("insert successfully by console");

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}
	}

}

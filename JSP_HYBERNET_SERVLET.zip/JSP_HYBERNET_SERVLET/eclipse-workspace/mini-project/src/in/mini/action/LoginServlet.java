package in.mini.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.mini.dao.LoginDao;
import in.mini.dao.RegisterDao;
import in.mini.dao.User;

@WebServlet("/login-action")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			User user = new User(username,password,null,null);
			System.out.println(user.getUsername());
			System.out.println(user.getPassword());
			boolean check = LoginDao.checkUser(user);
			if(check==true) {
				HttpSession session = request.getSession();
				session.setAttribute("my-auth", "1");
				response.sendRedirect("/mini-project/main-page.jsp?q=1");
			}else {
				throw new Exception("Auth fail");
			}
			
		}catch(Exception e) {
			e.fillInStackTrace();
			response.sendRedirect("/mini-project/login.jsp?q=0");
		}
			
	}

}

package day13.run;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import day13.entity.Employee;
import day13.entity.Student;

public class HelloHibernate {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	public static void main(String[] args) {
		addStudent();
		addEmployee();
	}
	public static void addStudent() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Student std1 = new Student("prafulla","prafulla@gmail.com","111111111");
		Student std2 = new Student("pranit","pranit@gmail.com","1111111112");
		Student std3 = new Student("payal","payal@gmail.com","1111111113");
		Student std4 = new Student("pratima","pratima@gmail.com","111111114");
		session.save(std1);
		session.save(std2);
		session.save(std3);
		session.save(std4);
		tx.commit();
		session.close();
		System.out.println("Element added");
	}
	public static void addEmployee() {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Employee std1 = new Employee("cse", "google", "aditya");
		Employee std2 = new Employee("ece", "tesla", "prafulla");
		Employee std3 = new Employee("ee", "electric car", "meetali");
		Employee std4 = new Employee("me", "tesla adv", "viraj");
		session.save(std1);
		session.save(std2);
		session.save(std3);
		session.save(std4);
		tx.commit();
		session.close();
		System.out.println("Employee added");
	}
}

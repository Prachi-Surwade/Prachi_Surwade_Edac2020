package day13.run;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import day13.entity.Student;

public class HibernateNativQuesry {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public static void main(String[] args) {
		// Demo1();
		//Demo2();
		Demo3();
	}

	public static void Demo1() {
		Session session = sessionFactory.openSession();
		String sql = "SELECT * FROM Student";
		List<Student> list = session.createNativeQuery(sql, Student.class).list();
		list.stream().map(Student::getName).forEach(System.out::println);
		session.close();
		System.out.println("run successfully");
	}

	public static void Demo2() {
		Session session = sessionFactory.openSession();
		String sql = "SELECT * FROM Student WHERE id=? AND name=?";
		List<Student> list = session.createNativeQuery(sql, Student.class)
										.setParameter(1,4)
										.setParameter(2,"pratima")
										.list();
		list.stream().map(Student::getName).forEach(System.out::println);
		session.close();
	}
	public static void Demo3() {
		Session session = sessionFactory.openSession();
		String sql = "SELECT * FROM Student WHERE id=:id AND name=:name";
		List<Student> list = session.createNativeQuery(sql,Student.class)
										.setParameter("id",3)
										.setParameter("name","payal")
										.list();
		list.stream().map(Student::getName).forEach(System.out::println);
		
		session.close();
	}
}

package firstprogram;

public class Main1 {
	public static void main(String[] args) {
		int arr1[]=new int[6];
		int arr2[]=new int[4];
		int arr[]=new int[10];
		arr1[0]=1;
		arr1[1]=5;
		arr1[2]=9;
		arr1[0]=10;
		arr1[0]=15;
		arr1[0]=20;
		arr2[0]=2;
		arr2[0]=3;
		arr2[0]=8;
		arr2[0]=13;
		for(int i=0;i<10; i++)
		{
			if(i<7)
			{
				arr[i]=arr1[i];
			}
			else {
				arr[i]=arr2[i];
			}
		}
		for(int i=0;i<11;i++)
		{
			System.out.println(arr[i]);
		}
	}
	
	
}

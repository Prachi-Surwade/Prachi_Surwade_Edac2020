package in.edac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSpring3 {
	private static final ApplicationContext contex =  new ClassPathXmlApplicationContext("spring.xml");
	@Autowired
	private static UserDao user3;
	public static void main(String[] args) {
		System.out.println("hello world");
		
		
		System.out.println(user3);
		
		
	}
	
}

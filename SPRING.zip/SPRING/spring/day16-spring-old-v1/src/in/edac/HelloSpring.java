package in.edac;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSpring {
	private static final ApplicationContext contex =  new ClassPathXmlApplicationContext("spring.xml");
	public static void main(String[] args) {
		System.out.println("hello world");
		System.out.println(contex);
	}
	
}

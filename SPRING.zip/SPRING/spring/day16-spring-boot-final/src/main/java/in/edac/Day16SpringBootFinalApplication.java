package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16SpringBootFinalApplication implements CommandLineRunner {
	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(Day16SpringBootFinalApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		createDemo();
		//update();
		//delete();
		findAll();
	}
	public void createDemo() {
		User user = new User("prafulla","1234","prafulla@gmail.com","9564365148");
		userRepository.save(user);
	}
	public void update() {
		User user = userRepository.findById(1).get();
		user.setUsername("pranit gundare");
		userRepository.save(user);
	}
	public void delete() {
		userRepository.deleteById(3);
		
	}
	public void findAll() {
		List<User> list = userRepository.findAll();
		list.stream().map(User::getUsername).forEach(System.out::println);
		list.stream().map(User::getPassword).forEach(System.out::println);
	}
	

}

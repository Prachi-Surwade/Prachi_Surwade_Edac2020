package in.edac;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CartRepository extends JpaRepository<Cart,Integer>{
//	@Query(nativeQuery = true, value = "SELECT * FROM cart")
//	public List<Cart> findAllCartNative();
//	
//	@Query(nativeQuery = true, value = "SELECT * FROM person WHERE id=?1")
//	public List<Person> findAllPersonNativeV1(long id);
//	
//	@Query(nativeQuery = true, value = "SELECT * FROM person WHERE id=:id")
//	public List<Person> findAllPersonNativeV2(@Param("id") long id);

}

package in.edac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class UserAction {
	@Autowired
	UserRepository userRepo;

	@GetMapping("/")
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView("login-views");
		return mv;
	}
	@GetMapping("/register-action-display")
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView("register-views");
		return mv;
	}
	@PostMapping("/create-user")
	public ModelAndView createUser(User user) {
		userRepo.save(user);
		ModelAndView mv =new ModelAndView("register-views");
		mv.addObject("q","1");
		return mv;
	}
	@PostMapping("/check-login-action")
	public ModelAndView checkLogin(User user) {
		User user1 = userRepo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		ModelAndView mv;
		if(user1!=null) {
			 mv = new ModelAndView("login-views");
			mv.addObject("q","1");
		}else {
		 mv = new ModelAndView("login-views");
			mv.addObject("q","0");
		}
		
		return mv;
	}
	
	
	
}

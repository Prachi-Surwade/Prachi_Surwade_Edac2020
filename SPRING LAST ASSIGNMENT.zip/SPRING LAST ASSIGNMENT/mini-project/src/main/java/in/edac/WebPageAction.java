package in.edac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/webpage-action")
public class WebPageAction {
	@Autowired
	ItemsRepository itemRepo;
	
	@Autowired
	CartRepository cartRepo;
	@GetMapping("/")
	public ModelAndView vegMenuDisplay() {
		
		ModelAndView mv = new ModelAndView("veg-menu-views");
		return mv;
	}
	@GetMapping("/nonvegmenu-display")
	public ModelAndView nonvegMenuDisplay() {
		ModelAndView mv = new ModelAndView("nonveg-menu-views");
		return mv;
	}
	@GetMapping("/select-item-action")
	public ModelAndView selectedItem(String id1) {
		int id = Integer.parseInt(id1);
		Item value = itemRepo.findById(id).get();
		Cart cart = new Cart(value.getName(),value.getPrize());
		cartRepo.save(cart);
		ModelAndView mv = new ModelAndView("veg-menu-views");
		return mv;
	}
	
	@GetMapping("/delete-cart")
	public ModelAndView delete() {
		ModelAndView mv = new ModelAndView("veg-menu-views");
		cartRepo.deleteAll();
		return mv;
	}
	@GetMapping("/findall-items")
	public ModelAndView findallCart() {
		int sum=0;
		ModelAndView mv = new ModelAndView("cart-views");
		List<Cart> list = cartRepo.findAll();
		for(int i=0 ; i<list.size() ; i++) {
			sum = sum + list.get(i).getPrize();
		}
		mv.addObject("itemList", list);
		mv.addObject("Total",sum);
		return mv;
	}
	
	@GetMapping("/deletebyid-item")
	public ModelAndView delete(String id1) {
		int id = Integer.parseInt(id1);
		int sum=0;
		cartRepo.deleteById(id);
		List<Cart> list = cartRepo.findAll();
		for(int i=0 ; i<list.size() ; i++) {
			sum = sum + list.get(i).getPrize();
		}
		ModelAndView mv = new ModelAndView("cart-views");
		mv.addObject("itemList", list);
		mv.addObject("Total",sum);
		return mv;
	}
	

}

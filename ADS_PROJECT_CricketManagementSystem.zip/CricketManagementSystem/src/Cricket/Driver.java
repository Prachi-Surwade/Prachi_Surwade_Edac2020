package Cricket;

import java.util.Scanner;

public class Driver {

   public static void main(String[] args) {
	BasicInfo b=new BasicInfo();
        //Linklist lb=new Linklist();
      
		
	Scanner sc=new Scanner(System.in);
		
	System.err.println("\n\n_________ Welcome to Titans Cricket Coaching Club _________");
	System.out.println("\n");
		
	//try {
		//While loop for Main menu
	     while (true)
             {
                 
		System.out.println("1)Signup \n\n2)Login \n\n3)Exit");
			
		System.out.println();
		System.out.println("Enter your choice:: ");
		int choice = sc.nextInt();
		
//=======================case for signup ======================================
		switch (choice) 
                { 
			
                case 1:
                      try{
			b.addData();
                      }
                      catch(Exception ae)
                      {
                          
                      }
                      
		/*System.out.println("\n\nPlease fill your basic information::\n");
				
     		System.out.println("\nEnter Your Name : ");
		sc.nextLine();
	        String name=sc.nextLine();
	        b.setName(name);
			   // System.out.println(b.getName());/**/
	       /*int age=0;
	       while(true) {
		 System.out.println("\nEnter Your Age : ");
                 age=sc.nextInt();
		 if ( age<=0){
		     System.out.println("Invalid age !!");
                 }
	         else if(age<8)
		  System.out.println("Sorry..! You're Underage..!!\nWe've no batches for this age group..!!!!");
	         else if(age >=8 && age<=100)
	            {b.setAge(age);
		     break;		
			    //	System.out.println(b.getAge());/**/
		   //}
	           /* else if(age >100)
                    {
			 System.out.println("Sorry..Too old to join !! ");
			 continue;
			    	
		    }
               }
              
               while(true) {
                    System.out.println("\nEnter Your Gender : ");
		    String gender=sc.next();
		    String g=gender.toLowerCase();
                    if(g.equals("female")||g.equals("male")) {
		       b.setGender(g);
				//System.out.println(b.getGender());/***/
		      /* break;
		       }
	           else {
			   System.out.println("Sorry..!! Invalid input..!!");
			   continue;
		        }
				
		}
				  		    
			   
				
			//validation for contact num
			while(true) {
				
			
				System.out.println("\nEnter Your Contact Number : ");
				long number=sc.nextLong();
				long num=number;
				int count=0;
				while(num!=0) {
					num/=10;
					++count;
				}
				if(count==10) {
				b.setContact_no(number);
				//System.out.println(b.getContact_no());
				break;
				}
				
				else
				{
					System.out.println("Sorry..!! Invalid Contact Number..!!");
					continue;
					
				}
			}	
		
			
			
			System.out.println("\nEnter Your City : ");
			
				String city=sc.next();
				b.setCity(city);
				//System.out.println(b.getCity());
			    
			    
				boolean  flag=true;
				while(flag) {
					System.out.println("\n\nArea of Intrest :: ");
					System.out.println("\n1) Batsmen \n2) Bowler \n3) Allrounder \n4) Wicket Keeper Batsmen");
					int select=sc.nextInt();
					switch(select) {
					case 1:
						String interest="Batsmen";
						b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
						
					case 2:
						 interest="Bowler";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
						
					case 3:
						 interest="Allrounder";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;	
					
					case 4:
						 interest="Wicket Keeper Batsmen";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
					default:
						System.out.println("Sorry..!! Invalid selection..!!");
						flag=true;
						break;	
					
					}
				}
				
				
				boolean  fl=true;
				while(fl) {

					System.out.println("\n\nChoose Your batch :: \n\n1) Week Batch \n2) Weekend Batch \n3) Full Week Batch \n4) Special Batch ");
					int batch=sc.nextInt();
					
					switch(batch) {
					case 1:
						String batchType="Week Batch";
						b.setBatch(batchType);
						fl=false;
						break;
						
					case 2:
						batchType="Weekend Batch";
						b.setBatch(batchType);
						fl=false;
						break;
						
					case 3:
						batchType="Full Week Batch";
						b.setBatch(batchType);
						fl=false;
						break;	
					
					case 4:
						 batchType="Special Batch";
						b.setBatch(batchType);
						fl=false;
						break;
					default:
						System.out.println("Sorry..!! Invalid Batch Type Selection..!!");
						fl=true;
						break;	
					
					}
				}
				
				boolean  go=true;
				while(go) {

					System.out.println("\n\nChoose Batch Timing :: \n\n1) Morning:- 6:45 AM to 9:00 AM \n2) Evening:- 3:45 PM to 6:00 AM" );
					int bt=sc.nextInt();
					
					switch(bt) {
					case 1:
						String batchTime=" Morning:- 6:45 AM to 9:00 AM"; 
						b.setTime(batchTime);
						go=false;
						break;
						
					case 2:
						batchTime="Evening:- 3:45 PM to 6:00 AM";
						b.setTime(batchTime);
						go=false;
						break;
						
				
					
					default:
						System.out.println("Sorry..!! Invalid Batch Time Selection..!!");
						go=true;
						break;	
					
					}
				}
				
				String id=b.generateId();
				System.out.println("\n\nYour generated ID :: "+id );
				System.out.println();
				System.out.println();
				System.out.println("\n\nMonthly fee of every batch is Rs.5000/-. "
						+ "\nPlease Login to pay Advance Fee to Confirm Your Admission/"
						+ "\n\nThank You..!!\n\n\n");
                                
		    
                               lb.addData(name,gender, age, contact_no, mail_id, city);*/
				break;
                    
                    
			
			
			
			//================================ case for login ======================================
			case 2:
				
				System.out.println("\n\n\nPlease Enter Your ID to Login ");
				String entId=sc.next();
				b.verifyId(entId);
				
				while(true) {
					System.out.println("=========================================================================================\n");
					System.out.println("\n\n1) View My Profile \n\n2) View My Batch Information \n\n3) View My Fees Status and Details \n\n4) Sign Out"
							+ "\n\nChoose an Option :: " );
					int sel=sc.nextInt();
					
					switch(sel) {
					
					case 1:
						b.viewProfile();
						
						break;
						
					case 2:
						b.viewBatchInfo();
						
						break;
						
					case 3:
						b.feesDet();
				
						break;
						
					case 4:
						 String arr[]= {"\n\nThank You..!!"};
						main(arr);
					  
					default:
						System.out.println("Sorry..!! Invalid Selection..!!");
						continue;
					}
				}
				
				
			
			//============================ exit part ========================
			case 3:
				System.out.println("Thank You  :)");
				System.exit(0);;				
				default:
					System.out.println("Sorry..!! Invalid Option Chosen..!!!");
					continue;
			}// main switch
		}//main while
   }
}
		
	
//}
package Cricket;

/*class Node1
{
    String name;
    String gender;
    int age;
    long contact_no;
    String mail_id;
    String city; 
    //BasicInfo data;
    Node1 next;
     public Node1()
    {
    }    
    
    public Node1(String name, String gender, int age, long contact_no, String mail_id, String city )
    { 
        this.name=name;
        this.gender=gender;
    this.age=age;
    this. contact_no=contact_no;
   this. mail_id=mail_id;
    this.city=city; 
        
        next=null;
    }        
}*/
public class Linklist
{
   
    Node1 head;
     int length;
    Linklist()
    {
      head=null;
      length=0;
    }

  void addData(String name, String gender, int age, long contact_no, String mail_id, String city)
  {
    Node1 newNode= new Node1(name, gender, age, contact_no, mail_id, city);
    if(head==null)
    {
         head=newNode;
         length++;
    }
   else
   {
    Node1 n=head; 
     while(n.next!=null)
     {
      n=n.next;
     }
    n.next=newNode; 
   }
  length++;
 }
}
/*void display()
{
   Node1 n;//For traverse
   if(front==null && rare==null)
   {
        System.out.println("NO Addmition");
   }
   else
   {
         n=front;
         while(n!=null)
         {
              System.out.println(""+n.data);
              n=n.next;
         }
    }
               

}*/
package cricket;

public class Bowler extends Role {
	
	
 public double bowlingAvg() {
	 return runs_conceded/wickets_taken;
	 
 }
	public double economy() {
		return runs_conceded/overs;
		
		
		
	}
	
	 
	
}
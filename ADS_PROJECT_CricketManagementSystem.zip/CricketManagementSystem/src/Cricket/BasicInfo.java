package Cricket;

import java.util.Scanner;

public class BasicInfo 
{
Scanner sc1=new Scanner(System.in); 
	

 private String name;
 private String gender;
 private int age;
 private long contact_no;
 private String mail_id;
 private String city;
 private String interest;
 private String batchType;
 private String batchTime;
 static private double balance;
 private double totalFees=5000;
 private String uid = "TCA000";
 private int prefix;
 private int nodesize=56; //id
 private String your_id="123";
 private double amount;
 private int logCount=0;
 int c=0;
 int size=5;
public BasicInfo() {}		//default constructor 
 
public BasicInfo(String name, String gender, int age, long contact_no, String mail_id, String city ){
	this.name = name;
	this.gender = gender;
	this.age = age;
	this.contact_no = contact_no;
	this.mail_id = mail_id;
	this.city = city;
}
BasicInfo b=new BasicInfo();
 Linklist lb=new Linklist();
 public void addData()
 {   
     if(c<size)
     System.out.println("\n\nPlease fill your basic information::\n");
		Scanner sc=new Scanner(System.in);		
     		System.out.println("\nEnter Your Name : ");
		sc.nextLine();
	        String name=sc.nextLine();
	        b.setName(name);
			   // System.out.println(b.getName());/**/
	       int age=0;
	       while(true) {
		 System.out.println("\nEnter Your Age : ");
                 age=sc.nextInt();
		 if ( age<=0){
		     System.out.println("Invalid age !!");
                 }
	         else if(age<8)
		  System.out.println("Sorry..! You're Underage..!!\nWe've no batches for this age group..!!!!");
	         else if(age >=8 && age<=100)
	            {b.setAge(age);
		     break;		
			    //	System.out.println(b.getAge());/**/
		    }
	            else if(age >100)
                    {
			 System.out.println("Sorry..Too old to join !! ");
			 continue;
			    	
		    }
               }
              
               while(true) {
                    System.out.println("\nEnter Your Gender : ");
		    String gender=sc.next();
		    String g=gender.toLowerCase();
                    if(g.equals("female")||g.equals("male")) {
		       b.setGender(g);
				//System.out.println(b.getGender());/***/
		       break;
		       }
	           else {
			   System.out.println("Sorry..!! Invalid input..!!");
			   continue;
		        }
				
		}
				  		    
			   
				
			//validation for contact num
			while(true) {
				
			
				System.out.println("\nEnter Your Contact Number : ");
				long number=sc.nextLong();
				long num=number;
				int count=0;
				while(num!=0) {
					num/=10;
					++count;
				}
				if(count==10) {
				b.setContact_no(number);
				//System.out.println(b.getContact_no());
				break;
				}
				
				else
				{
					System.out.println("Sorry..!! Invalid Contact Number..!!");
					continue;
					
				}
			}	
		
			
			
			System.out.println("\nEnter Your City : ");
			
				String city=sc.next();
				b.setCity(city);
				//System.out.println(b.getCity());
			    
			    
				boolean  flag=true;
				while(flag) {
					System.out.println("\n\nArea of Intrest :: ");
					System.out.println("\n1) Batsmen \n2) Bowler \n3) Allrounder \n4) Wicket Keeper Batsmen");
					int select=sc.nextInt();
					switch(select) {
					case 1:
						String interest="Batsmen";
						b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
						
					case 2:
						 interest="Bowler";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
						
					case 3:
						 interest="Allrounder";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;	
					
					case 4:
						 interest="Wicket Keeper Batsmen";
						 b.setAreaOfInt(interest);
						//b.getAreaOfInt();
						flag=false;
						break;
					default:
						System.out.println("Sorry..!! Invalid selection..!!");
						flag=true;
						break;	
					
					}
				}
				
				
				boolean  fl=true;
				while(fl) {

					System.out.println("\n\nChoose Your batch :: \n\n1) Week Batch \n2) Weekend Batch \n3) Full Week Batch \n4) Special Batch ");
					int batch=sc.nextInt();
					
					switch(batch) {
					case 1:
						String batchType="Week Batch";
						b.setBatch(batchType);
						fl=false;
						break;
						
					case 2:
						batchType="Weekend Batch";
						b.setBatch(batchType);
						fl=false;
						break;
						
					case 3:
						batchType="Full Week Batch";
						b.setBatch(batchType);
						fl=false;
						break;	
					
					case 4:
						 batchType="Special Batch";
						b.setBatch(batchType);
						fl=false;
						break;
					default:
						System.out.println("Sorry..!! Invalid Batch Type Selection..!!");
						fl=true;
						break;	
					
					}
				}
				
				boolean  go=true;
				while(go) {

					System.out.println("\n\nChoose Batch Timing :: \n\n1) Morning:- 6:45 AM to 9:00 AM \n2) Evening:- 3:45 PM to 6:00 AM" );
					int bt=sc.nextInt();
					
					switch(bt) {
					case 1:
						String batchTime=" Morning:- 6:45 AM to 9:00 AM"; 
						b.setTime(batchTime);
						go=false;
						break;
						
					case 2:
						batchTime="Evening:- 3:45 PM to 6:00 AM";
						b.setTime(batchTime);
						go=false;
						break;
						
				
					
					default:
						System.out.println("Sorry..!! Invalid Batch Time Selection..!!");
						go=true;
						break;	
					
					}
				}
				
				String id=b.generateId();
				System.out.println("\n\nYour generated ID :: "+id );
				System.out.println();
				System.out.println();
				System.out.println("\n\nMonthly fee of every batch is Rs.5000/-. "
						+ "\nPlease Login to pay Advance Fee to Confirm Your Admission/"
						+ "\n\nThank You..!!\n\n\n");
                                
		    
                               lb.addData(name,gender, age, contact_no, mail_id, city);
				
 }        

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public long getContact_no() {
	return contact_no;
}
public void setContact_no(long contact_no) {
	this.contact_no = contact_no;
}
public String getMail_id() {
	return mail_id;
}
public void setMail_id(String mail_id) {
	this.mail_id = mail_id;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

public void setAreaOfInt(String interest) {
	this.interest=interest;
}

public void getAreaOfInt() {
	System.out.println(interest);
}
 
public void setBatch(String batchType) {
	this.batchType=batchType;
	
}
public void getBatch() {
	System.out.print(batchType);
}
public void setTime(String batchTime) {
	this.batchTime=batchTime;
}
public void getTime() {
	System.out.print(batchTime);
	//return batchTime;
}
public double showFees(double amount) {
	balance=totalFees-amount;
	return balance;
}



public String generateId()
{
	prefix=nodesize;
	String spref = String.valueOf(prefix);
	//System.out.println(spref);
	 your_id = uid+spref;
//	System.out.println(your_id);
	return your_id;
}



//     =============== login part ===================     //


public void verifyId(String entId) {
	while(true) {
		
		
	if(your_id.equals(entId)) {
		
		break;
	}
	else {
		System.out.println("\nEnter Again...!!");
		String entId1=sc1.next();
		verifyId(entId1);
		if(your_id.equals(entId1));
		
		break;
	    }
		
	
	
    }
}

public void viewProfile() {
	System.out.println("Name: "+getName());
	System.out.println();
	System.out.println("Age: "+getAge());
	System.out.println();	
	System.out.println("Gender: "+getGender());
	System.out.println();
	System.out.println("Contact Number: "+getContact_no());
	System.out.println();
	System.out.println("City: "+getCity());
	System.out.println();
	System.out.print("Area of Interest: ");
	getAreaOfInt();
	System.out.println();
	System.out.println();
}


public void viewBatchInfo() {
	System.out.print("\nBatch Type: ");getBatch();
	System.out.println();
	
	System.out.print("\nAlloted Batch: "); batchAlloted();
	System.out.println();
	
	System.out.print("\nBatch Time: "); getTime();
	System.out.println();
}



public void conAdmission(double amount) {
while(true) {
	
	this.amount=amount;
	if(this.amount <1000) {
		System.out.println("\nPay At least Rs.1000 to confirm your admission.");
		double amount1=sc1.nextDouble();
		conAdmission(amount1);
		break;
	}
	else if(this.amount >5000) {
		System.out.println("\nYou have paid more than fees amount ");
		double amount1=sc1.nextDouble();
		conAdmission(amount1);
		break;
	}
	else if (this.amount >=1000 && this.amount<=5000) {
		balance=totalFees-this.amount;
		System.out.println("\nYou have paid Rs."+this.amount+"/-." );
		//System.out.println("your outstanding fees is Rs."+balance);
		break;
	}
	
	}
}

public void batchAlloted() {
	
	if(age>=8 && age<=12)
		System.out.print("UNDER 12 batch");
	else if(age>=12 && age <=14)
		System.out.print("UNDER 14 batch");
	else if(age>=14 && age <=16)
		System.out.print("UNDER 16 batch");
	else if(age>=16 && age <=19)
		System.out.print("UNDER 19 batch");
	else if(age>=19 && age <=70)
		System.out.print("OPEN batch");
	else 
		System.out.print("\nSorry..!!! We've no batches for this age group..!! ");
}


public void feesDet() {
	
	
	
	if(logCount==0) {
	boolean Flag=true;
	if(Flag) {
		System.out.println("\n Pay your advance fees :: ");
		amount=sc1.nextDouble();
		conAdmission(amount);
		Flag=false;
		logCount=1;
		feesDet();
		}}
	else {
		boolean flg=true;
		while(flg) {
	System.out.println("\n\n1) Fees Status \n2) Pay Fees ");
	int fs=sc1.nextInt();
	

	switch(fs) {
	case 1:
		pend();
		flg=false;
		
		break;
		
	case 2:
		payFees();
		flg=false;
		break;
		
	}}
	
}}	
	
public void pend() {
	if(balance!=0) {
		System.out.println("\nYour fee is Pending..!!");
		System.out.println("Outstanding Amount is : Rs."+balance+"/-.");
		
	}
	else
		System.out.println("\nYou have paid your fees.. :)");
}

public void payFees() {
	if(balance>0) {
	System.out.println("\nEnter amount to pay :: ");
	amount=sc1.nextDouble();
	if(amount<=balance) {
	balance=balance-amount;
	System.out.println("\nYou have paid Rs."+amount+"/-. \nPeding amount is Rs."+balance+"/-.");
}
	else if(amount>balance)
		System.out.println("\nYou are paying more than outstanding amount... :O ");
	}
	else {
		System.out.println("\nYou have already paid your fees.. :* ");
	}
	}

}
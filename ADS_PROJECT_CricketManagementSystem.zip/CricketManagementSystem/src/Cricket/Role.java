package cricket;

public class Role {
	
	protected int matches_played;
	protected int runs_scored;
	protected int wickets_taken;
	protected int runs_conceded;
	protected int overs;
	protected int wickets;
	protected int times_out;
	protected int centuries;
	protected int fifties;
	protected int caught;
	protected int stumped;
	
	//==============================================
	public int getMatches_played() {
		return matches_played;
	}
	public void setMatches_played(int matches_played) {
		this.matches_played = matches_played;
	}
	public int getRuns_scored() {
		return runs_scored;
	}
	public void setRuns_scored(int runs_scored) {
		this.runs_scored = runs_scored;
	}
	public int getWickets_taken() {
		return wickets_taken;
	}
	public void setWickets_taken(int wickets_taken) {
		this.wickets_taken = wickets_taken;
	}
	public int getRuns_conceded() {
		return runs_conceded;
	}
	public void setRuns_conceded(int runs_conceded) {
		this.runs_conceded = runs_conceded;
	}
	public int getOvers() {
		return overs;
	}
	public void setOvers(int overs) {
		this.overs = overs;
	}
	public int getWickets() {
		return wickets;
	}
	public void setWickets(int wickets) {
		this.wickets = wickets;
	}
	public int getTimes_out() {
		return times_out;
	}
	public void setTimes_out(int times_out) {
		this.times_out = times_out;
	}
	public int getCenturies() {
		return centuries;
	}
	public void setCenturies(int centuries) {
		this.centuries = centuries;
	}
	public int getFifties() {
		return fifties;
	}
	public void setFifties(int fifties) {
		this.fifties = fifties;
	}
	public int getCaught() {
		return caught;
	}
	public void setCaught(int caught) {
		this.caught = caught;
	}
	public int getStumped() {
		return stumped;
	}
	public void setStumped(int stumped) {
		this.stumped = stumped;
	}
	

}
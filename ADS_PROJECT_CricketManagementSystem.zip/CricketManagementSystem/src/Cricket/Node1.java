package Cricket;

class Node1
{
    String name;
    String gender;
    int age;
    long contact_no;
    String mail_id;
    String city; 
    //BasicInfo data;
    Node1 next;
     public Node1()
    {
    }    
    
    public Node1(String name, String gender, int age, long contact_no, String mail_id, String city )
    { 
        this.name=name;
        this.gender=gender;
    this.age=age;
    this. contact_no=contact_no;
   this. mail_id=mail_id;
    this.city=city; 
        
        next=null;
    }        
}